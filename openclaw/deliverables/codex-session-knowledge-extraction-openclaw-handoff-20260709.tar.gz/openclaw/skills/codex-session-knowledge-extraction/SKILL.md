---
name: codex-session-knowledge-extraction
description: Convert a bounded codex_knowledge_evidence_pack into zero to three human-readable, durable Wiki candidates with explicit qualification gates and indexable script, test, command, file, symbol, and code references. Use when OpenClaw or FastAPI needs to decide whether a Codex session contains reusable knowledge worth publishing, produce a structured memory_draft for review, or return no_wiki without reading local rollout files or full transcripts.
---

# Codex Session Knowledge Extraction

## Core Contract

Use only the provided `codex_knowledge_evidence_pack`. Do not read files, fetch URLs, resume Codex, approve actions, infer from hidden transcript data, or request extra context.

Return exactly one JSON object and no Markdown outside JSON. Keep JSON keys, enum values, file paths, commands, code identifiers, package names, and quoted error excerpts unchanged. Write all user-facing prose in Simplified Chinese.

The default result is `no_wiki`. Produce a Wiki candidate only when another engineer can understand and apply it without reading the source session.

## Desired Result

Extract publishable knowledge, not a session taxonomy or progress report. A useful candidate explains one reusable problem or rule with:

- a clear conclusion;
- when it applies;
- ordered actions or decision rules;
- failure signals and cautions;
- verification steps and expected signals;
- evidence refs;
- indexable references back to scripts, tests, commands, files, symbols, or exact evidence code snippets.

Do not emit broad lists of concepts, timelines, or tools merely because they appear in the evidence.

## Decision Workflow

1. Reconstruct the durable outcome from `session.last_summary`, `facts.work_items`, `facts.methods`, user intent, assistant conclusions, failures, and checks.
2. Separate lasting knowledge from task progress, temporary errors, file inventories, and duplicated authoritative documentation.
3. Group evidence into independent candidate topics. Do not combine unrelated lessons into one Wiki page.
4. Apply the qualification gate below.
5. For each surviving candidate, create one readable `memory_draft` and link every relevant implementation reference through `code_refs`.
6. Return at most three candidates. Prefer one strong candidate over several weak candidates.

## Qualification Gate

Evaluate every candidate on these dimensions:

- `resolved`: the rule, decision, or fix is known; discovery-only observations fail.
- `actionable`: a reader can take concrete action.
- `self_contained`: the draft makes sense without the session transcript.
- `reusable`: it applies beyond the exact session id or one temporary artifact.
- `durable`: it is likely to remain useful after the current task.
- `novel`: it adds operational value rather than restating an existing Skill or project document.
- `verified`: evidence contains a successful check or a reliable expected signal. If the knowledge is strong but final success evidence is missing, use `publish_status=needs_evidence`.
- `code_linked`: when scripts, commands, tests, files, or symbols are present, the candidate links to them through `code_refs`.

Use `publish_status` as follows:

- `ready`: all required dimensions pass and verification evidence is present.
- `needs_review`: the candidate is useful but novelty, scope, or wording needs human judgment.
- `needs_evidence`: the candidate is useful but final verification evidence is missing.

Do not mark `ready` when `verified=false`.

## Destination And Rejection Rules

Reject or redirect these items:

- task progress, completion summaries, changed-file lists, and phase narration;
- session-specific ids, timestamps, artifact inventories, or one-off cleanup;
- unresolved guesses or failures without a confirmed fix;
- rules already fully defined in an authoritative Skill/spec unless the candidate adds a reusable operational explanation;
- temporary test maintenance noise;
- commands without a reusable problem, decision, method, or verification role.

Use one of these `reason_code` values for rejected items:

`status_only`, `temporary_noise`, `unresolved`, `not_reusable`, `duplicate_authoritative_doc`, `insufficient_evidence`, `belongs_in_project_doc`, `low_value`.

It is correct to return zero candidates.

## Evidence Priority

Use evidence in this order:

1. `session.last_summary` for the final claimed outcome.
2. `facts.successful_checks`, successful `facts.methods`, and indexed tests for verified results.
3. `facts.failed_commands`, `facts.errors`, and failed methods for symptoms and failure signals.
4. `facts.work_items` for decisions, implementation sequence, and cause/effect.
5. `facts.user_messages` and `facts.assistant_messages` for intent, reasoning, and conclusions.
6. `code_index` and `facts.changed_files` for implementation indexing.
7. `evidence[*]` for bounded supporting excerpts.

When the final summary claims success but structured success evidence is absent, preserve the knowledge candidate only as `needs_evidence`.

## Code And Script Indexing

Use only references already present in the input `code_index`. FastAPI builds this index from commands, methods, changed files, symbols, and evidence excerpts before calling OpenClaw.

Return a top-level `code_index` containing only references used by candidates. Each reference must have a unique `ref_id`. Candidate steps and verification items link to these references through `code_refs`.

Rules:

- Preserve exact paths, commands, symbols, and snippets from evidence.
- When reusing an input code reference, copy its `ref_id`, kind, path, symbol, line numbers, command, language, snippet, outcome, exit code, and evidence refs exactly. Do not repair, normalize, reformat, or rewrite them.
- Do not create a new `ref_id`. If an implementation reference is missing from the input `code_index`, omit the code reference, mention the evidence gap, and use `needs_evidence` when it blocks verification.
- Never invent line numbers, file paths, commands, symbols, code, or successful outcomes.
- Set unknown `path`, `symbol`, line numbers, command, snippet, exit code, or outcome to null.
- Use `kind=script` or `kind=test` for executable file references, `kind=command` for command-only references, `kind=source_file` for implementation files, `kind=symbol` for named code symbols, `kind=config` for configuration, and `kind=doc` only when the document is needed to apply the candidate.
- Use `snippet` only for exact evidence code. Do not synthesize implementation code.
- A command that verifies the candidate belongs in both `code_index` and the relevant `verification[*].commands`.
- Candidate `code_refs` must directly implement or verify that candidate. Do not attach generic docs validation, repository hygiene, TODO counts, formatting checks, or unrelated failed commands merely because they occurred in the same session.
- A code reference used only by a rejected item must not appear in a Wiki candidate's `code_refs` or verification list.
- Verification must test the candidate's behavior or decision rule. Put incidental maintenance checks in `rejected_items`.
- Keep at most 12 code references.

## Output Schema

Return this shape:

```json
{
  "schema_version": 1,
  "disposition": "no_wiki | wiki_candidates",
  "assessment": {
    "summary": "string",
    "candidate_count": 0,
    "needs_human_review": true,
    "evidence_refs": ["string"]
  },
  "wiki_candidates": [
    {
      "candidate_id": "stable-kebab-case-id",
      "destination": "wiki_runbook | wiki_pitfall | wiki_methodology | wiki_decision",
      "publish_status": "ready | needs_review | needs_evidence",
      "memory_draft": {
        "knowledge_kind": "runbook | pitfall | methodology | decision | rule",
        "title": "string",
        "problem": "string",
        "root_cause": "string | null",
        "when_to_use": "string",
        "prerequisites": ["string"],
        "decision_or_rule": "string | null",
        "steps": [
          {
            "order": 1,
            "instruction": "string",
            "rationale": "string | null",
            "commands": ["string"],
            "file_refs": ["string"],
            "code_refs": ["string"],
            "evidence_refs": ["string"]
          }
        ],
        "verification": [
          {
            "order": 1,
            "check": "string",
            "commands": ["string"],
            "expected_signal": "string",
            "code_refs": ["string"],
            "evidence_refs": ["string"]
          }
        ],
        "failure_signals": ["string"],
        "cautions": ["string"],
        "open_questions": ["string"],
        "source_summary": "string",
        "tags": ["string"]
      },
      "quality_gate": {
        "resolved": true,
        "actionable": true,
        "self_contained": true,
        "reusable": true,
        "durable": true,
        "novel": true,
        "verified": true,
        "code_linked": true
      },
      "scores": {
        "reusability": 0.0,
        "novelty": 0.0,
        "actionability": 0.0,
        "durability": 0.0,
        "evidence_quality": 0.0,
        "confidence": 0.0
      },
      "code_refs": ["string"],
      "evidence_refs": ["string"]
    }
  ],
  "rejected_items": [
    {
      "title": "string",
      "reason_code": "status_only | temporary_noise | unresolved | not_reusable | duplicate_authoritative_doc | insufficient_evidence | belongs_in_project_doc | low_value",
      "reason": "string",
      "evidence_refs": ["string"]
    }
  ],
  "code_index": [
    {
      "ref_id": "code-ref-id",
      "kind": "script | test | command | source_file | symbol | config | doc",
      "path": "string | null",
      "symbol": "string | null",
      "line_start": "integer | null",
      "line_end": "integer | null",
      "command": "string | null",
      "language": "string | null",
      "snippet": "string | null",
      "purpose": "string | null",
      "outcome": "success | failure | pending | unknown | null",
      "exit_code": "integer | null",
      "evidence_refs": ["string"]
    }
  ]
}
```

## Candidate Writing Rules

- Write titles as conclusions or actionable topics, not project phases.
- Make `problem`, `when_to_use`, `decision_or_rule`, steps, failure signals, and verification readable without hidden context.
- Keep one candidate focused on one lesson.
- Use ordered steps only when order matters.
- State the authority or precedence rule explicitly when the evidence establishes one.
- Put exact commands in `commands`; link them to `code_index` through `code_refs`.
- Mention evidence limitations in `open_questions` and lower `evidence_quality` when structured success evidence is missing.
- Do not copy long session summaries into `source_summary`; summarize the evidence that supports this candidate.

## Minimal Example

For evidence showing that an active navigation item was incorrectly resized from ordinary-item consensus, a valid candidate should explain the authority rule, failure signals, application steps, and verification tests. It should link the exact seed-handoff test script through a code reference. If the session claims the tests passed but the pack lacks a successful command result, return `publish_status=needs_evidence` and `quality_gate.verified=false`.

## Final Quality Bar

Return `disposition=no_wiki` when no candidate passes the reusable, actionable, self-contained, and durable gates.

For `disposition=wiki_candidates`:

- `assessment.candidate_count` must equal the number of candidates;
- every candidate must have non-empty `problem`, `when_to_use`, `source_summary`, steps or a concrete decision rule, and verification;
- every `code_refs` value must resolve to a top-level `code_index[*].ref_id`;
- every exact command, file, symbol, line number, snippet, outcome, and exit code must come from evidence;
- `publish_status=ready` requires `quality_gate.verified=true`;
- use `needs_evidence` instead of inventing successful verification.
